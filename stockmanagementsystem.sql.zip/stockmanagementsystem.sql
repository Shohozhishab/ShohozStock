-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2026 at 11:18 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockmanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `ComName` varchar(155) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `country`, `ComName`, `role_id`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'imranertaza12@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Syed Imran Ertaza', 1924329315, 'Noapara, Abhaynagar, Jessore', 'profile_1664976903_39bd3bf1ddc2da4682f0.jpg', NULL, NULL, 1, '1', '2023-08-06 10:35:27', 1, 1, '2023-08-06 10:35:27', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `account_no` bigint(20) NOT NULL,
  `balance` double UNSIGNED NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `sch_id`, `name`, `account_no`, `balance`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(12, 3, 'IFIC Bank', 55235235235, 5500, '1', '2026-03-08 11:00:26', 2, NULL, '2026-03-08 13:04:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `image` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `chaque`
--

CREATE TABLE `chaque` (
  `chaque_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `chaque_number` int(11) NOT NULL,
  `to_name` varchar(155) DEFAULT NULL,
  `to` int(11) DEFAULT NULL,
  `from_name` varchar(155) DEFAULT NULL,
  `from` int(11) DEFAULT NULL,
  `from_loan_provider` int(11) DEFAULT NULL,
  `amount` float UNSIGNED NOT NULL,
  `issue_date` date NOT NULL,
  `account_number` int(11) DEFAULT NULL,
  `status` enum('Pending','Bounce','Approved') NOT NULL DEFAULT 'Pending',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `father_name` varchar(55) DEFAULT NULL,
  `mother_name` varchar(55) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `present_address` text DEFAULT NULL,
  `age` int(10) UNSIGNED DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `pic` varchar(55) DEFAULT NULL,
  `nid` varchar(155) DEFAULT NULL,
  `cus_type_id` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `balance` double NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `sch_id`, `customer_name`, `father_name`, `mother_name`, `address`, `present_address`, `age`, `mobile`, `pic`, `nid`, `cus_type_id`, `status`, `balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(28, 3, 'Sumon', NULL, NULL, NULL, NULL, NULL, '1923149437', NULL, NULL, 28, '1', 0, '2026-03-08 04:23:52', 2, 2, '2026-03-08 16:25:00', NULL, NULL),
(29, 3, 'Sumon', NULL, NULL, NULL, NULL, NULL, '19231494366', NULL, NULL, 28, '1', 600.5, '2026-03-09 11:21:29', 2, 2, '2026-03-10 13:07:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_type`
--

CREATE TABLE `customer_type` (
  `cus_type_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `type_name` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_type`
--

INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(28, 3, 'Reguler', '2026-03-08 04:23:40', 2, NULL, '2026-03-08 16:23:40', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `salary` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `balance` float UNSIGNED DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `sch_id`, `name`, `salary`, `age`, `balance`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(8, 3, 'murad', 5000, 28, 4000, '1', '2026-03-08 10:42:48', 2, 2, '2026-03-08 11:01:29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gen_settings`
--

CREATE TABLE `gen_settings` (
  `settings_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `label` varchar(155) NOT NULL,
  `value` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gen_settings`
--

INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(11, 2, 'barcode_img_size', '100', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(12, 2, 'barcode_type', 'C128A', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(13, 2, 'business_type', 'Ownership business', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(14, 2, 'currency', 'BDT', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(15, 2, 'currency_before_symbol', '৳', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(16, 2, 'currency_after_symbol', '/-', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(17, 2, 'running_year', '2018-2019', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(18, 2, 'disable_frontend', '0', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(19, 2, 'phone_code', '880', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(20, 2, 'country', 'Bangladesh', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(21, 3, 'barcode_img_size', '100', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(22, 3, 'barcode_type', 'C128A', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(23, 3, 'business_type', 'Ownership business', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(24, 3, 'currency', 'BDT', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(25, 3, 'currency_before_symbol', '৳', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(26, 3, 'currency_after_symbol', '/-', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(27, 3, 'running_year', '2018-2019', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(28, 3, 'disable_frontend', '0', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(29, 3, 'phone_code', '880', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(30, 3, 'country', 'Bangladesh', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(31, 3, 'edit_permission_expire', '10', '2025-05-19 19:50:50', NULL, NULL, '2025-05-20 11:49:10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gen_settings_super`
--

CREATE TABLE `gen_settings_super` (
  `settings_id_sup` int(10) UNSIGNED NOT NULL,
  `label` varchar(155) NOT NULL,
  `value` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gen_settings_super`
--

INSERT INTO `gen_settings_super` (`settings_id_sup`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'loading_message', 'Please wait until it is processing...', '2023-09-02 10:22:44', 0, NULL, '2023-09-02 10:22:44', NULL, NULL),
(2, 'site_title', 'Shohoz Hishab | Accounting management system', '2023-09-02 10:22:44', 0, NULL, '2023-09-02 10:22:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `pymnt_type_id` int(11) DEFAULT NULL,
  `customer_name` varchar(155) DEFAULT NULL,
  `amount` float UNSIGNED NOT NULL,
  `entire_sale_discount` int(11) DEFAULT NULL,
  `vat` int(11) DEFAULT NULL,
  `final_amount` float UNSIGNED NOT NULL,
  `profit` float NOT NULL COMMENT 'Profit on the sale',
  `nagad_paid` float UNSIGNED DEFAULT NULL,
  `bank_paid` float UNSIGNED DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `chaque_paid` float UNSIGNED DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `due` float UNSIGNED DEFAULT NULL,
  `creation_timestamp` int(11) DEFAULT NULL,
  `payment_timestamp` longtext DEFAULT NULL,
  `payment_method` longtext DEFAULT NULL,
  `payment_details` longtext DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `year` longtext DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_id`, `sch_id`, `customer_id`, `pymnt_type_id`, `customer_name`, `amount`, `entire_sale_discount`, `vat`, `final_amount`, `profit`, `nagad_paid`, `bank_paid`, `bank_id`, `chaque_paid`, `chaque_id`, `due`, `creation_timestamp`, `payment_timestamp`, `payment_method`, `payment_details`, `status`, `timestamp`, `year`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(15, 3, 28, NULL, NULL, 1500, 0, 0, 1500, 100, 1500, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '1', '2026-03-08 10:24:15', NULL, '2026-03-08 04:24:15', 2, 2, '2026-03-08 16:24:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_item`
--

CREATE TABLE `invoice_item` (
  `inv_item` int(10) UNSIGNED NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `sch_id` int(11) NOT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `title` varchar(155) DEFAULT NULL COMMENT 'It will be used, if prod_id is not inserted into the table.',
  `price` float UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `total_price` float UNSIGNED NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `final_price` float UNSIGNED NOT NULL,
  `profit` float NOT NULL COMMENT 'Profit on individual product',
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `invoice_item`
--

INSERT INTO `invoice_item` (`inv_item`, `invoice_id`, `sch_id`, `prod_id`, `title`, `price`, `quantity`, `total_price`, `discount`, `final_price`, `profit`, `date`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(20, 15, 3, 18, NULL, 1500, 1, 1500, 0, 1500, 100, '2026-03-08 16:24:15', '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger`
--

CREATE TABLE `ledger` (
  `ledg_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `service_invoice_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ledger`
--

INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `service_invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(55, 3, 28, 15, NULL, NULL, NULL, NULL, 'Sales Cash Due', 'Dr.', 1500, 1500, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(56, 3, 28, 15, NULL, NULL, NULL, NULL, 'Sales Cash Pay', 'Cr.', 1500, 0, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(57, 3, 28, NULL, NULL, NULL, 2, NULL, 'Return Sale Product', 'Cr.', 1500, -1500, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL),
(58, 3, 28, NULL, NULL, NULL, 2, NULL, 'Return Sale Product cash Pay', 'Dr.', 1500, 0, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL),
(59, 3, 29, NULL, NULL, 124, NULL, NULL, 'test', 'Dr.', 600.5, 600.5, '2026-03-09 11:21:40', 2, NULL, '2026-03-10 13:07:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_bank`
--

CREATE TABLE `ledger_bank` (
  `ledgBank_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `service_invoice_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ledger_bank`
--

INSERT INTO `ledger_bank` (`ledgBank_id`, `sch_id`, `bank_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `service_invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(33, 3, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Deposit', 'Dr.', 10000, 10000, '2026-03-08 11:01:05', NULL, NULL, '2026-03-08 12:54:06', NULL, NULL),
(34, 3, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Deposit', 'Dr.', 500, 10500, '2026-03-08 12:36:25', NULL, NULL, '2026-03-08 12:54:06', NULL, NULL),
(35, 3, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Withdraw', 'Cr.', 5000, 5500, '2026-03-08 12:56:32', NULL, NULL, '2026-03-08 13:04:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_discount`
--

CREATE TABLE `ledger_discount` (
  `discount_ledg_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ledger_nagodan`
--

CREATE TABLE `ledger_nagodan` (
  `ledg_nagodan_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `loan_pro_id` int(11) DEFAULT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `service_invoice_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_nagodan`
--

INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `service_invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(69, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test', 'Dr.', 50000, 50000, '2026-03-08 10:42:33', 2, NULL, '2026-03-08 10:42:33', NULL, NULL),
(70, 3, NULL, NULL, NULL, NULL, NULL, 121, NULL, NULL, NULL, NULL, NULL, 'Salary', 'Cr.', 4000, 46000, '2026-03-08 10:43:03', 2, NULL, '2026-03-08 11:01:29', NULL, NULL),
(71, 3, NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Deposit', 'Cr.', 10000, 36000, '2026-03-08 11:01:05', NULL, NULL, '2026-03-08 12:54:06', NULL, NULL),
(72, 3, NULL, NULL, NULL, NULL, NULL, 122, NULL, NULL, NULL, NULL, NULL, '10000', 'Dr.', 10000.5, 38000.5, '2026-03-08 12:33:05', 2, NULL, '2026-03-10 13:06:55', NULL, NULL),
(73, 3, NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Deposit', 'Cr.', 500, 45499.5, '2026-03-08 12:36:25', NULL, NULL, '2026-03-10 13:06:55', NULL, NULL),
(74, 3, NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Withdraw', 'Dr.', 5000, 50500.5, '2026-03-08 12:56:32', NULL, NULL, '2026-03-10 13:06:55', NULL, NULL),
(75, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, NULL, 'Sales Cash Pay', 'Dr.', 1500, 52000.5, '2026-03-08 04:24:15', 2, NULL, '2026-03-10 13:06:55', NULL, NULL),
(76, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'Return Sale Cash Pay', 'Cr.', 1500, 50499.5, '2026-03-08 04:25:00', 2, NULL, '2026-03-10 13:06:55', NULL, NULL),
(77, 3, NULL, NULL, NULL, NULL, NULL, 123, NULL, NULL, NULL, NULL, NULL, 'test', 'Cr.', 500, 50000.5, '2026-03-09 11:21:16', 2, NULL, '2026-03-10 13:06:55', NULL, NULL),
(78, 3, NULL, NULL, NULL, NULL, NULL, 124, NULL, NULL, NULL, NULL, NULL, 'test', 'Cr.', 600.5, 50601, '2026-03-09 11:21:40', 2, NULL, '2026-03-10 13:07:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_profit`
--

CREATE TABLE `ledger_profit` (
  `profit_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_profit`
--

INSERT INTO `ledger_profit` (`profit_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(14, 3, 15, NULL, 'Sales profit get', 'Cr.', 100, -100, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(15, 3, NULL, 2, 'Return Profit', 'Dr.', 100, 0, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_sales`
--

CREATE TABLE `ledger_sales` (
  `ledgSale_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_sales`
--

INSERT INTO `ledger_sales` (`ledgSale_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(14, 3, 15, NULL, 'New Sale amount', 'Cr.', 1500, -1500, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(15, 3, NULL, 2, 'return sale', 'Dr.', 1500, 0, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_stock`
--

CREATE TABLE `ledger_stock` (
  `stock_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_stock`
--

INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(25, 3, NULL, NULL, 14, 'New purchase amount', 'Dr.', 140000, 140000, '2026-03-08 04:22:54', 2, NULL, '2026-03-08 16:22:54', NULL, NULL),
(26, 3, 15, NULL, NULL, 'Sale amount', 'Cr.', 1400, 138600, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(27, 3, NULL, 2, NULL, 'Return sale', 'Dr.', 1400, 140000, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL),
(28, 3, NULL, NULL, NULL, 'New Existing Products Add Amount', 'Dr.', 5000, 145000, '2026-03-11 03:32:47', 2, NULL, '2026-03-11 15:32:47', NULL, NULL),
(29, 3, NULL, NULL, NULL, 'New Existing Products Add Amount', 'Dr.', 14000, 159000, '2026-03-12 09:10:10', 2, NULL, '2026-03-12 09:10:10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_vat`
--

CREATE TABLE `ledger_vat` (
  `ledg_vat_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `vat_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_vat`
--

INSERT INTO `ledger_vat` (`ledg_vat_id`, `sch_id`, `vat_id`, `invoice_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(14, 3, 2, 15, NULL, 'Return Sale Vat return', 'Dr.', 0, 0, '2026-03-08 16:25:00', 3, NULL, '2026-03-08 16:25:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `license`
--

CREATE TABLE `license` (
  `lic_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `lic_key` text COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `license`
--

INSERT INTO `license` (`lic_id`, `sch_id`, `lic_key`, `start_date`, `end_date`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(2, 2, '651ac4dd948c7', '2023-10-02', '2026-10-06', '1', '2023-10-02 19:25:49', NULL, NULL, '2023-10-02 19:25:49', NULL, NULL),
(3, 3, '651b8c5336dc2', '2023-10-03', '2030-12-31', '1', '2023-10-03 09:36:51', NULL, NULL, '2023-10-03 09:36:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(3, '2023-08-06-034752', 'App\\Database\\Migrations\\Admin', 'default', 'App', 1691296280, 1),
(4, '2023-08-06-050108', 'App\\Database\\Migrations\\Bank', 'default', 'App', 1691591167, 2),
(5, '2023-08-29-130121', 'App\\Database\\Migrations\\CreateBankDepositTable', 'default', 'App', 1693314325, 3),
(6, '2023-08-29-130632', 'App\\Database\\Migrations\\CreateBankWithdrawTable', 'default', 'App', 1693314497, 4),
(13, '2023-08-30-051417', 'App\\Database\\Migrations\\CreateBrandTable', 'default', 'App', 1693375265, 5),
(14, '2023-08-30-052222', 'App\\Database\\Migrations\\CreateChaqueTable', 'default', 'App', 1693375265, 5),
(16, '2023-08-30-061545', 'App\\Database\\Migrations\\CreateCustomersTable', 'default', 'App', 1693376996, 6),
(17, '2023-08-30-113923', 'App\\Database\\Migrations\\CreateCustomerTypeTable', 'default', 'App', 1693396448, 7),
(19, '2023-08-31-035553', 'App\\Database\\Migrations\\CreateEmployeeTable', 'default', 'App', 1693454627, 8),
(20, '2023-09-02-040549', 'App\\Database\\Migrations\\CreateGeneralSettingsTable', 'default', 'App', 1693627691, 9),
(21, '2023-09-02-041941', 'App\\Database\\Migrations\\CreateGeneralSettingsSuper', 'default', 'App', 1693628522, 10),
(23, '2023-09-02-052043', 'App\\Database\\Migrations\\CreateInvoiceTable', 'default', 'App', 1693633627, 11),
(25, '2023-09-02-055851', 'App\\Database\\Migrations\\CreateInvoiceItemTable', 'default', 'App', 1693636404, 12),
(27, '2023-09-02-064307', 'App\\Database\\Migrations\\CreateLcTable', 'default', 'App', 1693637263, 13),
(28, '2023-09-02-064843', 'App\\Database\\Migrations\\CreateLedgerTable', 'default', 'App', 1693637827, 14),
(29, '2023-09-02-114902', 'App\\Database\\Migrations\\CreateLedgerBankTable', 'default', 'App', 1693655916, 15),
(30, '2023-09-02-120046', 'App\\Database\\Migrations\\CreateLedgerCapitalTable', 'default', 'App', 1693656198, 16),
(31, '2023-09-02-120438', 'App\\Database\\Migrations\\CreateLedgerDiscountTable', 'default', 'App', 1693656612, 17),
(32, '2023-09-02-121229', 'App\\Database\\Migrations\\CreateLedgerEmployeeTable', 'default', 'App', 1693656947, 18),
(33, '2023-09-02-121818', 'App\\Database\\Migrations\\CreateLedgerExpenseTable', 'default', 'App', 1693657241, 19),
(34, '2023-09-02-122309', 'App\\Database\\Migrations\\CreateLedgerLoanTable', 'default', 'App', 1693657539, 20),
(36, '2023-09-02-131316', 'App\\Database\\Migrations\\CreateLedgerCashTable', 'default', 'App', 1693661001, 21),
(37, '2023-09-02-132543', 'App\\Database\\Migrations\\CreateLedgerOtherSalesTable', 'default', 'App', 1693661572, 22),
(38, '2023-09-02-133416', 'App\\Database\\Migrations\\CreateLedgerProfitTable', 'default', 'App', 1693661976, 23),
(39, '2023-09-02-134140', 'App\\Database\\Migrations\\CreateLedgerPurchaseTable', 'default', 'App', 1693662392, 24),
(40, '2023-09-02-134827', 'App\\Database\\Migrations\\CreateLedgerSalesTable', 'default', 'App', 1693662675, 25),
(41, '2023-09-02-135213', 'App\\Database\\Migrations\\CreateLedgerStockTable', 'default', 'App', 1693662893, 26),
(42, '2023-09-02-135626', 'App\\Database\\Migrations\\CreateLedgerSuppliersTable', 'default', 'App', 1693663221, 27),
(43, '2023-09-02-140208', 'App\\Database\\Migrations\\CreateLedgerVatTable', 'default', 'App', 1693663488, 28),
(44, '2023-09-05-043422', 'App\\Database\\Migrations\\CreateLicenseTable', 'default', 'App', 1693888703, 29),
(46, '2023-09-05-044711', 'App\\Database\\Migrations\\CreateAccountHeadTable', 'default', 'App', 1693890038, 30),
(47, '2023-09-05-050915', 'App\\Database\\Migrations\\CreateMoneyReceiptTable', 'default', 'App', 1693890807, 31),
(48, '2023-09-06-034629', 'App\\Database\\Migrations\\CreatePackageTable', 'default', 'App', 1693972265, 32),
(49, '2023-09-09-035823', 'App\\Database\\Migrations\\CreatePaymentTypeTable', 'default', 'App', 1694232050, 33),
(50, '2023-09-09-040712', 'App\\Database\\Migrations\\CreateProductsTable', 'default', 'App', 1694233613, 34),
(51, '2023-09-09-130211', 'App\\Database\\Migrations\\CreateProductCategoryTable', 'default', 'App', 1694264990, 35),
(52, '2023-09-09-133650', 'App\\Database\\Migrations\\CreatePurchaseTable', 'default', 'App', 1694266921, 36),
(53, '2023-09-09-134518', 'App\\Database\\Migrations\\CreatePurchaseItemTable', 'default', 'App', 1694267376, 37),
(54, '2023-09-16-033102', 'App\\Database\\Migrations\\CreateReturnPurchaseTable', 'default', 'App', 1694835937, 38),
(55, '2023-09-16-034720', 'App\\Database\\Migrations\\CreateReturnPurchaseItemTable', 'default', 'App', 1694836411, 39),
(57, '2023-09-16-041635', 'App\\Database\\Migrations\\CreateReturnSaleTable', 'default', 'App', 1694838173, 40),
(58, '2023-09-16-042450', 'App\\Database\\Migrations\\CreateReturnSaleItemTable', 'default', 'App', 1694838555, 41),
(59, '2023-09-16-103104', 'App\\Database\\Migrations\\CreateRoleTable', 'default', 'App', 1694860525, 42),
(60, '2023-09-16-103740', 'App\\Database\\Migrations\\CreateSalesTable', 'default', 'App', 1694860842, 43),
(61, '2023-09-16-104244', 'App\\Database\\Migrations\\CreateShopsTable', 'default', 'App', 1694861576, 44),
(62, '2023-09-16-115122', 'App\\Database\\Migrations\\CreateStoresTable', 'default', 'App', 1694865560, 45),
(63, '2023-10-01-042738', 'App\\Database\\Migrations\\CreateSuppliersTable', 'default', 'App', 1696134719, 46),
(64, '2023-10-01-043628', 'App\\Database\\Migrations\\CreateTransactionTable', 'default', 'App', 1696135481, 47),
(65, '2023-10-01-045006', 'App\\Database\\Migrations\\CreateUsersTable', 'default', 'App', 1696136118, 48),
(66, '2023-10-01-045745', 'App\\Database\\Migrations\\CreateVatRegisterTable', 'default', 'App', 1696136443, 49),
(67, '2023-10-01-050151', 'App\\Database\\Migrations\\CreateWarrantyManageTable', 'default', 'App', 1696136714, 50);

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `package_id` int(10) UNSIGNED NOT NULL,
  `package_name` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `package_all_permission` text COLLATE utf8_unicode_ci NOT NULL,
  `package_admin_permission` text COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `name` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `unit` int(11) NOT NULL,
  `purchase_price` float NOT NULL,
  `selling_price` float NOT NULL,
  `purchase_date` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Last purchase price will be added here.',
  `supplier_id` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `serial_number` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `picture` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `warranty` varchar(55) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barcode` varchar(55) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prod_cat_id` int(11) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prod_id`, `sch_id`, `store_id`, `name`, `quantity`, `unit`, `purchase_price`, `selling_price`, `purchase_date`, `supplier_id`, `size`, `serial_number`, `brand_id`, `picture`, `warranty`, `barcode`, `prod_cat_id`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(18, 3, 3, 'twinmos 4gb ', 100, 1, 1400, 1500, '2026-03-08 16:22:54', 23, NULL, NULL, NULL, NULL, NULL, NULL, 20, '2026-03-08 04:22:54', 2, 2, '2026-03-08 16:25:00', NULL, NULL),
(19, 3, 3, 'test', 10, 1, 500, 550, '2026-03-11 15:32:47', NULL, NULL, NULL, NULL, 'product_1773222596_ff1bb735827fac9b281f.jpg', NULL, NULL, 20, '2026-03-11 15:32:47', 2, NULL, '2026-03-11 15:49:59', NULL, NULL),
(20, 3, 3, 'murad', 10, 1, 1400, 1500, '2026-03-12 09:10:10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-12 09:10:10', 2, NULL, '2026-03-12 09:10:10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `prod_cat_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `parent_pro_cat` int(11) NOT NULL,
  `product_category` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`prod_cat_id`, `sch_id`, `parent_pro_cat`, `product_category`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(19, 3, 0, 'Ram', '1', '2026-03-08 04:21:54', 2, NULL, '2026-03-08 16:21:54', NULL, NULL),
(20, 3, 19, 'DDR4', '1', '2026-03-08 04:22:01', 2, NULL, '2026-03-08 16:22:01', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `role` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `permission` text COLLATE utf8_unicode_ci NOT NULL,
  `is_default` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `sch_id`, `role`, `permission`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(2, 2, 'Admin', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Pages\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Customers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase_item\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Product_category\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank_deposit\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Settings\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank_withdraw\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Warranty_manage\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Suppliers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\",\"discount\":\"1\",\"warranty\":\"1\",\"vat_option\":\"1\"},\"Role\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Money_receipt\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Loan_provider\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_suppliers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_nagodan\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_loan\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Stores\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_lc\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_bank\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Invoice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\",\"discount\":\"1\",\"warranty\":\"1\"},\"Expense_category\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Balance_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Lc_installment\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Lc\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Customer_type\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Products\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Transaction\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chaque\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Stock_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Sales_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Daily_book\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Brand\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Employee\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_employee\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Return_sale\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Return_purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vat_register\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_vat\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Acquisition_due\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Owe_amount\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Trial_balance\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Capital\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_capital\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_profit\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_stock\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_expense\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"HeadToheadTransfer\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_other_sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_discount\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Previous_data_show\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service_type\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service_invoice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_service_charge\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"}}', '1', '2023-10-02 07:24:29', 1, NULL, '2024-12-26 18:52:26', NULL, NULL),
(3, 3, 'Admin', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Pages\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Customers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase_item\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Product_category\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank_deposit\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Settings\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank_withdraw\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Warranty_manage\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Suppliers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\",\"discount\":\"1\",\"warranty\":\"1\",\"vat_option\":\"1\"},\"Role\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Money_receipt\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Loan_provider\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_suppliers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_nagodan\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_loan\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Stores\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_lc\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_bank\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Invoice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\",\"discount\":\"1\",\"warranty\":\"1\"},\"Expense_category\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Balance_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Lc_installment\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Lc\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Customer_type\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Products\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Transaction\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chaque\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Stock_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Sales_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Daily_book\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Brand\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Employee\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_employee\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Return_sale\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Return_purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vat_register\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_vat\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Acquisition_due\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Owe_amount\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Trial_balance\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Capital\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_capital\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_profit\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_stock\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_expense\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"HeadToheadTransfer\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_other_sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_discount\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Previous_data_show\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service_type\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service_invoice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_service_charge\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"}}', '1', '2023-10-03 09:36:23', 1, NULL, '2024-12-26 18:52:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `sch_id`, `invoice_id`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(13, 3, 15, '2026-03-08 04:24:15', NULL, NULL, '2026-03-08 16:24:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shops`
--

CREATE TABLE `shops` (
  `sch_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cash` float UNSIGNED NOT NULL COMMENT 'This is the nagad cash of the shop owner.',
  `capital` float DEFAULT NULL,
  `profit` float DEFAULT NULL,
  `service_charge` float DEFAULT NULL,
  `stockAmount` float DEFAULT NULL,
  `expense` float DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `purchase_balance` float NOT NULL,
  `sale_balance` float NOT NULL,
  `address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `opening_status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `shops`
--

INSERT INTO `shops` (`sch_id`, `name`, `email`, `cash`, `capital`, `profit`, `service_charge`, `stockAmount`, `expense`, `discount`, `purchase_balance`, `sale_balance`, `address`, `mobile`, `comment`, `logo`, `image`, `package_id`, `status`, `opening_status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(2, 'Khan', 'khan@gmail.com', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '1', '0', '2023-10-02 19:24:29', NULL, NULL, '2025-12-27 11:53:00', NULL, NULL),
(3, 'murad', 'murad@gmail.com', 49400, -69000, 0, 0, 159000, 0, 0, 140000, 0, '', '1923121212', '', 'profile_1735210605_882fcfce2769d5b0e220.png', 'pro_1723435084_4bc1901ff94b73aaee24.jpg', NULL, '1', '1', '2023-10-03 09:36:23', NULL, 2, '2026-03-12 09:10:10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `store_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(115) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `is_default` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`store_id`, `sch_id`, `name`, `description`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(2, 2, 'Default', 'Default Store', '1', '2023-10-02 07:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(3, 3, 'Default', 'Default Store', '1', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `balance` float NOT NULL,
  `address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `sch_id`, `name`, `balance`, `address`, `phone`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(23, 3, 'murad', -140000, NULL, '01714070771', '1', '2026-03-08 04:22:12', 2, 2, '2026-03-08 16:22:54', NULL, NULL),
(24, 3, 'murad', 500, NULL, '01714070774', '1', '2026-03-09 11:21:04', 2, 2, '2026-03-10 12:54:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL,
  `is_default` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `permission` text COLLATE utf8_unicode_ci NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `sch_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `is_default`, `permission`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 2, 'khan@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Khan', NULL, NULL, '', 2, '1', '1', '', '2023-10-02 07:24:29', 1, NULL, '2023-10-02 19:25:49', NULL, NULL),
(2, 3, 'murad@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'murad', NULL, NULL, '', 3, '1', '1', '', '2023-10-03 09:36:23', 1, NULL, '2023-10-03 09:36:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vat_register`
--

CREATE TABLE `vat_register` (
  `vat_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `vat_register_no` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `balance` float NOT NULL,
  `is_default` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vat_register`
--

INSERT INTO `vat_register` (`vat_id`, `sch_id`, `name`, `vat_register_no`, `balance`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 2, 'Default Vat Name', 'BIN-0000-01', 0, '1', '2023-10-02 07:24:29', 1, NULL, '2023-10-02 19:24:29', NULL, NULL),
(2, 3, 'BIN-0000-01', 'BIN-0000-01', 0, '1', '2023-10-03 09:36:23', 1, 2, '2026-01-08 10:12:09', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `name` (`name`),
  ADD KEY `account_no` (`account_no`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `chaque`
--
ALTER TABLE `chaque`
  ADD PRIMARY KEY (`chaque_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `mobile` (`mobile`),
  ADD KEY `cus_type_id` (`cus_type_id`);

--
-- Indexes for table `customer_type`
--
ALTER TABLE `customer_type`
  ADD PRIMARY KEY (`cus_type_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `gen_settings`
--
ALTER TABLE `gen_settings`
  ADD PRIMARY KEY (`settings_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `gen_settings_super`
--
ALTER TABLE `gen_settings_super`
  ADD PRIMARY KEY (`settings_id_sup`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `pymnt_type_id` (`pymnt_type_id`);

--
-- Indexes for table `invoice_item`
--
ALTER TABLE `invoice_item`
  ADD PRIMARY KEY (`inv_item`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `prod_id` (`prod_id`);

--
-- Indexes for table `ledger`
--
ALTER TABLE `ledger`
  ADD PRIMARY KEY (`ledg_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `rtn_sale_id` (`rtn_sale_id`);

--
-- Indexes for table `ledger_bank`
--
ALTER TABLE `ledger_bank`
  ADD PRIMARY KEY (`ledgBank_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `bank_id` (`bank_id`),
  ADD KEY `money_receipt_id` (`money_receipt_id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `rtn_purchase_id` (`rtn_purchase_id`),
  ADD KEY `rtn_sale_id` (`rtn_sale_id`);

--
-- Indexes for table `ledger_discount`
--
ALTER TABLE `ledger_discount`
  ADD PRIMARY KEY (`discount_ledg_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `ledger_nagodan`
--
ALTER TABLE `ledger_nagodan`
  ADD PRIMARY KEY (`ledg_nagodan_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `bank_id` (`bank_id`),
  ADD KEY `loan_pro_id` (`loan_pro_id`),
  ADD KEY `money_receipt_id` (`money_receipt_id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `rtn_purchase_id` (`rtn_purchase_id`),
  ADD KEY `rtn_sale_id` (`rtn_sale_id`);

--
-- Indexes for table `ledger_profit`
--
ALTER TABLE `ledger_profit`
  ADD PRIMARY KEY (`profit_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `ledger_sales`
--
ALTER TABLE `ledger_sales`
  ADD PRIMARY KEY (`ledgSale_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `rtn_sale_id` (`rtn_sale_id`);

--
-- Indexes for table `ledger_stock`
--
ALTER TABLE `ledger_stock`
  ADD PRIMARY KEY (`stock_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `purchase_id` (`purchase_id`);

--
-- Indexes for table `ledger_vat`
--
ALTER TABLE `ledger_vat`
  ADD PRIMARY KEY (`ledg_vat_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `vat_id` (`vat_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `trans_id` (`trans_id`);

--
-- Indexes for table `license`
--
ALTER TABLE `license`
  ADD PRIMARY KEY (`lic_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`package_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `brand_id` (`brand_id`),
  ADD KEY `prod_cat_id` (`prod_cat_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`prod_cat_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`sch_id`),
  ADD KEY `email` (`email`),
  ADD KEY `package_id` (`package_id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`store_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `phone` (`phone`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `vat_register`
--
ALTER TABLE `vat_register`
  ADD PRIMARY KEY (`vat_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `bank_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chaque`
--
ALTER TABLE `chaque`
  MODIFY `chaque_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `customer_type`
--
ALTER TABLE `customer_type`
  MODIFY `cus_type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `gen_settings`
--
ALTER TABLE `gen_settings`
  MODIFY `settings_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `gen_settings_super`
--
ALTER TABLE `gen_settings_super`
  MODIFY `settings_id_sup` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `invoice_item`
--
ALTER TABLE `invoice_item`
  MODIFY `inv_item` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `ledger`
--
ALTER TABLE `ledger`
  MODIFY `ledg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `ledger_bank`
--
ALTER TABLE `ledger_bank`
  MODIFY `ledgBank_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `ledger_discount`
--
ALTER TABLE `ledger_discount`
  MODIFY `discount_ledg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ledger_nagodan`
--
ALTER TABLE `ledger_nagodan`
  MODIFY `ledg_nagodan_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `ledger_profit`
--
ALTER TABLE `ledger_profit`
  MODIFY `profit_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ledger_sales`
--
ALTER TABLE `ledger_sales`
  MODIFY `ledgSale_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ledger_stock`
--
ALTER TABLE `ledger_stock`
  MODIFY `stock_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `ledger_vat`
--
ALTER TABLE `ledger_vat`
  MODIFY `ledg_vat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `license`
--
ALTER TABLE `license`
  MODIFY `lic_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `package_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `prod_cat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `shops`
--
ALTER TABLE `shops`
  MODIFY `sch_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `store_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vat_register`
--
ALTER TABLE `vat_register`
  MODIFY `vat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
